TIYA — BEIGE AESTHETIC PORTFOLIO

1. Keep index.html, style.css and script.js in the same folder.
2. Open index.html in a browser to preview the site.
3. Replace hello@example.com in index.html with your real email address.
4. Replace the three demo project cards with screenshots and links to your real work.
5. Publish the folder using GitHub Pages or Netlify.

This website uses HTML, CSS and JavaScript. Google Fonts are loaded online.
